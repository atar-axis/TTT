/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @author Manuel Thurner
 */

//define function "bind" if native implementation is not available
if (!Function.prototype.bind) {
	Function.prototype.bind = function() { 
		var fn = this,
    		args = Array.prototype.slice.call(arguments),
    		object = args.shift();
		
		return function() { 
			return fn.apply(object, args.concat(Array.prototype.slice.call(arguments))); 
		};
	};
}

/**
 * Constants used for drawing, globally accessible
 */
var Constants = {
	hextileRaw: (1 << 0),
	hextileBackgroundSpecified: (1 << 1),
	hextileForegroundSpecified: (1 << 2),
	hextileAnySubrects: (1 << 3),
	hextileSubrectsColoured: (1 << 4)
};

/**
 * Utility functions, globally accessible
 */
var Utils = {
	/**
	 * Formats a number for displaying it in a time context, which means:
	 * - round the number to the previous integer
	 * - add a leading zero if smaller than 10
	 * 
	 * @param number		Number
	 * @return String		The formatted number.
	 */
	numberToDisplayTime: function(number) {
		number = Math.floor(number);
		if (number < 10) {
			number = "0"+number;
		}
		return number;
	},
	
	/**
	 * Converts a time number given in milliseconds to a string representing
	 * the the time, ready for displaying it to the user.
	 * 
	 * @param time		Number; In milliseconds.
	 * @return String	Formatted String representing time.
	 */
	timeToDisplayTime: function(time) {
		//remove milliseconds
		time /= 1000;
		//seconds
		var displayTime = this.numberToDisplayTime(time%60);
		//minutes + seconds
		displayTime = this.numberToDisplayTime((time/60)%60)+":"+displayTime;
		//hours
		if (time/60/60 > 0) {
			displayTime = Math.floor(time/60/60)+":"+displayTime;
		}
		
		return displayTime;
	}
};