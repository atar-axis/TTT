/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var SimpleAnnotation = new Class({
	Extends: Message,
	
	contains: function(x, y) {
		if (x >= this.properties.startX && x <= this.properties.endX &&
			y >= this.properties.startY && y <= this.properties.endY) {
			return true;
		}
		return false;
	}
	
});