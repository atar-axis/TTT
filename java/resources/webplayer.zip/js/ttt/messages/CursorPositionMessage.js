/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var CursorPositionMessage = new Class({
	Extends: Message,
	
	draw: function() {
		if (this.canvasPlayer.cursorNode) {
			$(this.canvasPlayer.cursorNode).attr("data-x", this.properties.x);
			$(this.canvasPlayer.cursorNode).attr("data-y", this.properties.y);
			
			$(this.canvasPlayer.cursorNode).css({
				left: (this.properties.x*this.canvasPlayer.scale)+"px",
				top: (this.properties.y*this.canvasPlayer.scale)+"px",
			})
		}
	}
	
});