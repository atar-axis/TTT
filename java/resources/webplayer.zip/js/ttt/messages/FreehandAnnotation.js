/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var FreehandAnnotation = new Class({
	Extends: Message,
	lineWidth: 2.5,
	
	draw: function() {
		this.canvasPlayer.annotationContext.strokeStyle = this.properties.color;
		this.canvasPlayer.annotationContext.lineWidth   = this.lineWidth;
		
		this.canvasPlayer.annotationContext.beginPath();
		if (this.properties.points.length > 1) {
			this.canvasPlayer.annotationContext.moveTo(this.properties.points[0].x, this.properties.points[0].y);
			for (var i = 1; i < this.properties.points.length; i++) {
				this.canvasPlayer.annotationContext.lineTo(this.properties.points[i].x, this.properties.points[i].y);
			}
			
		}
		this.canvasPlayer.annotationContext.stroke();
		this.canvasPlayer.addAnnotation(this);
	},

	contains: function(x, y) {
		if (this.properties.points.length > 0) {
			//calculate boundary
			var lowX = null;
			var lowY = null;
			var highX = null;
			var highY = null;
			
			for (var i = 0; i < this.properties.points.length; i++) {
				if (lowX == null || this.properties.points[i].x < lowX) {
					lowX = this.properties.points[i].x;
				}
				if (lowY == null || this.properties.points[i].y < lowY) {
					lowY = this.properties.points[i].y;
				}
				if (highX == null || this.properties.points[i].x > highX) {
					highX = this.properties.points[i].x;
				}
				if (highY == null || this.properties.points[i].y > highY) {
					highY = this.properties.points[i].y;
				}
			}
			
			//check if inside bounds
			if (x >= lowX && x <= highX && y >= lowY && y <= highY) {
				return true;
			}
		}
		return false;
	}
	
});