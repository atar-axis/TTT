/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var HextileMessage = new Class({
	Extends: Message,
	
	inputData: null,
	inputPointer: 0,
	
	initialize: function(canvasPlayer, message) {
		this.parent(canvasPlayer, message);
		
		this.inputData = this.canvasPlayer.base64Decode(this.properties.hextiles);
	},
	
	readNBytes: function(n) {
		var result = 0;
		for (var i = 0, shift = 0; i < n; i++, shift += 8) {
            result += (this.inputData[this.inputPointer] & 0xFF) << shift;
			this.inputPointer++;
        }
		
		return result;
	},
	
	handleRawRect: function(x, y, w, h) {
		var imageData = this.canvasPlayer.context.createImageData(w, h);
		for (var dy = 0; dy < h; dy++) {
			for (var dx = 0; dx < w; dx++) {
				var offset = (dy * w + dx)*4;
				var color = this.decodeColor(this.readNBytes(this.canvasPlayer.prefs.bytesPerPixel));
				imageData.data[offset+0] = color.red;
				imageData.data[offset+1] = color.green;
				imageData.data[offset+2] = color.blue;
				//alpha channel, set to opaque
				imageData.data[offset+3] = 255;
			}
		}
		this.canvasPlayer.context.putImageData(imageData, x, y);
	},
	
	handleHextileSubrect: function(tx, ty, tw, th) {
		//the first byte contains header information
		var subencoding = this.readNBytes(1);
		
		//check if the hextile contains raw data
		if ((subencoding & Constants.hextileRaw) != 0) {
            this.handleRawRect(tx, ty, tw, th);
            return;
        }
		
		//BG COLOR
		if ((subencoding & Constants.hextileBackgroundSpecified) != 0) {
            this.canvasPlayer.bgColor = this.decodeColor(this.readNBytes(this.canvasPlayer.prefs.bytesPerPixel));
        }
		
		//draw bg tile
		this.canvasPlayer.context.fillStyle = this.canvasPlayer.bgColor.css;
		this.canvasPlayer.context.fillRect(tx, ty, tw, th);
		
		//FG COLOR
		if ((subencoding & Constants.hextileForegroundSpecified) != 0) {
            this.canvasPlayer.fgColor = this.decodeColor(this.readNBytes(this.canvasPlayer.prefs.bytesPerPixel));
        }
		
		//done with this tile if there are no sub-rectangles.
        if ((subencoding & Constants.hextileAnySubrects) == 0) {
            return;
		}

        var nSubrects = this.readNBytes(1);

        var b1, b2, sx, sy, sw, sh;

        for (var j = 0; j < nSubrects; j++) {
            if ((subencoding & Constants.hextileSubrectsColoured) != 0) {
                //store foreground color
				this.canvasPlayer.fgColor = this.decodeColor(this.readNBytes(this.canvasPlayer.prefs.bytesPerPixel));
            }
            //decode subrect
            b1 = this.readNBytes(1) & 0xFF;
            b2 = this.readNBytes(1) & 0xFF;
            sx = tx + (b1 >> 4);
            sy = ty + (b1 & 0xf);
            sw = (b2 >> 4) + 1;
            sh = (b2 & 0xf) + 1;
			
			this.canvasPlayer.context.fillStyle = this.canvasPlayer.fgColor.css;
            this.canvasPlayer.context.fillRect(sx, sy, sw, sh);
        }
	},
	
	decodeColor: function(bytes) {
		var prefs = this.canvasPlayer.prefs;
		var rgb = {};
		
		switch (prefs.bitsPerPixel) {
		case 16:
			//if big endian, swap bytes
			if (prefs.bigEndian) {
				bytes = (bytes & 0xFF) << 8 | ((bytes & 0xFF00) >> 8);
			}
			rgb = {
				red: Math.ceil(((bytes & (prefs.redMax << prefs.redShift)) >> prefs.redShift)*255/prefs.redMax),
				green: Math.ceil(((bytes & (prefs.greenMax << prefs.greenShift)) >> prefs.greenShift)*255/prefs.greenMax),
				blue: Math.ceil(((bytes & (prefs.blueMax << prefs.blueShift)) >> prefs.blueShift)*255/prefs.blueMax)
			};
			break;
		case 8:
			
			break;
		//24
		default:
			if (prefs.bigEndian) {
				bytes = (bytes & 0xFF) << 24 | (bytes >> 8 & 0xFF) << 16 | (bytes >> 16 & 0xFF) << 8 | bytes >> 24 & 0xFF;
			}
		
			rgb = {
				red: (bytes >> 16 & 0xFF),
				green: (bytes >> 8 & 0xFF),
				blue: (bytes & 0xFF)
			};
			break;
		}
		
		rgb.css = "rgb("+rgb.red+","+rgb.green+","+rgb.blue+")";
		return rgb;
	},
	
	draw: function() {
		this.inputPointer = 0;
		
		for (var ty = this.properties.y; ty < this.properties.y + this.properties.height; ty += 16) {
			var th = 16;
			if (this.properties.y + this.properties.height - ty < 16) {
				th = this.properties.y + this.properties.height - ty;
			}
			
			for (var tx = this.properties.x; tx < this.properties.x + this.properties.width; tx += 16) {
				var tw = 16;
				if (this.properties.x + this.properties.width - tx < 16) {
					tw = this.properties.x + this.properties.width - tx;
				}
				
				this.handleHextileSubrect(tx, ty, tw, th);
			}
		}
	},
	
});