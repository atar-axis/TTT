/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @author Manuel Thurner
 */

var CursorMessage = new Class({
	Extends: Message,
	
	draw: function() {
		//remove old cursor
		if (this.canvasPlayer.cursorNode) {
			$(this.canvasPlayer.cursorNode).remove();
		}
		
		this.canvasPlayer.cursorNode = $("<img/>", {
			src: this.properties.image,
			//store original values for window resizing
			"data-width": this.properties.width,
			"data-height": this.properties.height,
			"data-x": this.properties.x,
			"data-y": this.properties.y,
		}).appendTo("body");
		
		//set position and size
		$(this.canvasPlayer.cursorNode).css({
			position: "absolute",
			width: Math.round(this.properties.width*this.canvasPlayer.scale)+"px",
			height: Math.round(this.properties.height*this.canvasPlayer.scale)+"px",
			left: Math.round(this.properties.x*this.canvasPlayer.scale)+"px",
			top: Math.round(this.properties.y*this.canvasPlayer.scale)+"px",
		});
	}
	
});