/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var RectangleAnnotation = new Class({
	Extends: SimpleAnnotation,
	
	draw: function() {
		this.canvasPlayer.annotationContext.strokeStyle = this.properties.color;
		this.canvasPlayer.annotationContext.strokeRect(this.properties.startX, this.properties.startY, this.properties.endX-this.properties.startX, this.properties.endY-this.properties.startY);
		this.canvasPlayer.addAnnotation(this);
	}
});