/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var Message = new Class({
	canvasPlayer: null,
	properties: {},
	
	//constructor
	initialize: function(canvasPlayer, message) {
		this.canvasPlayer = canvasPlayer;
		this.properties = message || {};
	},
	
	//abstract
	draw: function() {
		console.log("message not implemented", this.properties.type);
	},
	
	//abstract
	contains: function(x, y) {
		console.log("contains not implemented", this.properties.type)
	}
	
});