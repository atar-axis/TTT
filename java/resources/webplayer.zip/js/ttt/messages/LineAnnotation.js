/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var LineAnnotation = new Class({
	Extends: SimpleAnnotation,
	
	draw: function() {
		this.canvasPlayer.annotationContext.strokeStyle = this.properties.color;
		this.canvasPlayer.annotationContext.beginPath();
		this.canvasPlayer.annotationContext.moveTo(this.properties.startX, this.properties.startY);
		this.canvasPlayer.annotationContext.lineTo(this.properties.endX, this.properties.endY);
		this.canvasPlayer.annotationContext.stroke();
		this.canvasPlayer.addAnnotation(this);
	}
	
});