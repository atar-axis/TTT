/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var WhiteboardMessage = new Class({
	Extends: Message,
	
	draw: function() {
		if (this.properties.pageNumber > 0) {
			//activate whiteboard, fill the whole annotation board white
			this.canvasPlayer.annotationContext.fillStyle = "rgb(255,255,255)";
			this.canvasPlayer.annotationContext.fillRect(0, 0, this.canvasPlayer.prefs.framebufferWidth, this.canvasPlayer.prefs.framebufferHeight);
		} else {
			//disable whiteboard, clear the annotation board
			this.canvasPlayer.clearAnnotations(true);
		}
		//TODO: add support for multiple whiteboard pages and saving of framewise annotations
	}
});