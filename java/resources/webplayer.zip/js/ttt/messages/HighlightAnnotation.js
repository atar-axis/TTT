/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var HighlightAnnotation = new Class({
	Extends: SimpleAnnotation,
	
	draw: function() {
		this.canvasPlayer.annotationContext.globalAlpha = 0.25;
		this.canvasPlayer.annotationContext.fillStyle = this.properties.color;
		this.canvasPlayer.annotationContext.fillRect(this.properties.startX, this.properties.startY, this.properties.endX-this.properties.startX, this.properties.endY-this.properties.startY);
		this.canvasPlayer.annotationContext.globalAlpha = 1.0;
		this.canvasPlayer.addAnnotation(this);
	}
	
});