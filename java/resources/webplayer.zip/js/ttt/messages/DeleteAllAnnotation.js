/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var DeleteAllAnnotation = new Class({
	Extends: Message,
	
	draw: function() {
		this.canvasPlayer.clearAnnotations(true);
	}
	
});