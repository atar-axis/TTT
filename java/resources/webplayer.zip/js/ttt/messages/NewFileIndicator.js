/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var NewFileIndicator = new Class({
	Extends: Message,
	
	initialize: function(canvasPlayer, message) {
		this.parent(canvasPlayer, message);
		
		var script = document.createElement('script');
		script.type = 'text/javascript';
		script.src = this.properties.fileName;
		
		document.body.appendChild(script);
	},
	
	draw: function(controller) {
		controller.waitUntilDataFileLoaded(this.properties.id);
	}
});