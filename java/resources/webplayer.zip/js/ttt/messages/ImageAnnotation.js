/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var ImageAnnotation = new Class({
	Extends: Message,
	
	initialize: function(canvasPlayer, message) {
		this.parent(canvasPlayer, message);
		
		this.image = new Image();
		this.image.src = this.properties.image;
	},
	
	draw: function() {
		this.canvasPlayer.annotationContext.drawImage(this.image, this.properties.x, this.properties.y);
		this.canvasPlayer.addAnnotation(this);
	},
	
	contains: function() {
		if (x >= this.properties.x && x <= this.properties.x + this.properties.image.width &&
			y >= this.properties.y && y <= this.properties.y + this.properties.image.height) {
			isInBounds = true;
		}
	}
	
});