/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @Author Manuel Thurner
 */

var TextAnnotation = new Class({
	Extends: Message,
	
	draw: function() {
		this.canvasPlayer.annotationContext.fillStyle = this.properties.color;
		this.canvasPlayer.annotationContext.font = '16px Verdana, Arial, sans-serif';
		this.canvasPlayer.annotationContext.textBaseline = 'top';
		this.canvasPlayer.annotationContext.fillText(this.properties.text, this.properties.x, this.properties.y);
		this.canvasPlayer.addAnnotation(this);
	},

	contains: function() {
		//TODO: add support
	}
	
});