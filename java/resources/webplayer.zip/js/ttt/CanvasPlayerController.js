/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @author Manuel Thurner
 */

var CanvasPlayerController = new Class({
	//the DomNode containing the control elements
	containerSelector: null,
	//audio domNode
	audioTag: null,
	
	dataFilesLoaded: {},
	
	//internal properties for playing the messages:
	//array containing Message objects
	messages: [],
	//current play position
	msgCounter: 0,
	//the timeout until the next message is played
	timeoutHandle: null,
	isPlaying: true,
	
	//control domNodes
	playPauseNode: null,
	seekerNode: null,
	timeDisplayNode: null,
	//pop up dialogs, like volume and pitch
	popups: {
		/*Format:
		   "label": {
			triggerNode: null,
			node: null,
			isPoppedUp: false
		}*/
	},
	//is used to prevent updates to the seekerNode while seeking
	isSeeking: false,
	isSeekingTimeoutHandle: null,
	
	//function to be executed when locking next
	onLockFunc: null,
	
	//affects the video speed and is used to correct differences in audio and video time.
	syncModifier: 1.00,
	
	//construction parameters
	data: null,
	audioSelector: null,
	thumbnailsSelector: null,
	lockSelector: null,
	canvasPlayer: null,	
	options: {
		//wether the presentation should start automatically
		autoPlay: true,
	},
	
	
	
	/**
	 * Constructor, prepares everything for playing.
	 * 
	 * @param canvasPlayer			CanvasPlayer; The canvas player to be used.
	 * @param containerSelector		String; jQuery selector for the DomNode containing the control elements.
	 * @param audioSelector			String; jQuery selector for the Audio DomNode.
	 * @param thumbnailsSelector	String; jQuery selector for the thumbnails DomNode.
	 * @param lockSelector			String; jQuery selector for the locking DomNode which overlays
	 * 										the canvas while loading.
	 * @param options				Object; Further options, see options attribute.
	 */
	initialize: function(canvasPlayer, containerSelector, audioSelector, thumbnailsSelector, lockSelector, options) {
		$.extend(this.options, options);
		
		this.canvasPlayer = canvasPlayer;
		this.containerSelector = containerSelector;
		this.thumbnailsSelector = thumbnailsSelector;
		this.lockSelector = lockSelector;
		this.audioTag = $(audioSelector)[0];
		this.audioSelector = audioSelector;
		
		this.testPitchSupport();
		
		//retrieve cookied properties
		if ($.cookie('ttt-volume') !== null) {
			this.setVolume($.cookie('ttt-volume'));
		}
		if ($.cookie('ttt-pitch') !== null) {
			this.setPitch($.cookie('ttt-pitch')/100);
		}
		
		//link canvas element to resume/pause method.
		$(this.canvasPlayer.annotationCanvas).click($.proxy(this.togglePause, this));
		
		//window resizing
		$(window).resize($.proxy(function() {
			this.scaleDocument(true);
			this.movePopups();
		}, this));
	},
	
	
	
	/**
	 * Initializes the control DomNodes, creates jQuery UI components out of them and
	 * provides their functionality / links to it.
	 */
	setupControls: function() {
		//select all child elements having the data-role attribute
		var controls = $(this.containerSelector+" [data-role]");
		//loop over them and initialize them according to their role
		controls.each($.proxy(function(index, node) {
			var role = node.getAttribute("data-role");
			
			switch (role) {
			
			case "previous":
				//create button component
				$(node).button({
					text: false,
					icons: {
						primary: "ui-icon-seek-first"
					}
				});
				//and link the button to its function
				$(node).click(this.seekToAdjacentThumbnail.bind(this, true));
				break;
				
			case "next":
				$(node).button({
					text: false,
					icons: {
						primary: "ui-icon-seek-end"
					}
				});
				$(node).click(this.seekToAdjacentThumbnail.bind(this, false));
				break;
				
			case "play-pause":
				this.playPauseNode = node;
				$(node).button({
					text: false,
					icons: {
						primary: "ui-icon-pause"
					}
				});
				$(node).click($.proxy(this.togglePause, this));
				break;
				
			case "stop":
				$(node).button({
					text: false,
					icons: {
						primary: "ui-icon-stop"
					}
				});
				//seek to 100 when clicking stop so that the first slide is already drawn
				$(node).click(this.seekTo.bind(this, 100, true, true));
				break;
				
			case "seeker":
				this.seekerNode = node;
				//create label
				var label = document.createElement("div");
				$(label).addClass("seekerLabel box");
				$("body")[0].appendChild(label);
				
				//create ui slider component
				$(this.seekerNode).slider({
					range: "min",
					step: 5000,
					value: this.getCurrentTime(),
					min: 0,
					max: this.getMaximumTime(),
					//this is called after sliding or changing the value programmatically
					change: $.proxy(function(event, ui) {
						//only change when slider was not changed programmatically
						if (event.originalEvent) {
							this.seekTo(ui.value);
						}
					}, this),
					//this is called while sliding
					slide: $.proxy(function(event, ui) {
						//display label while sliding
						$(label).css("display", "block");
						$(label).css("top", $(this.seekerNode).offset().top-12);
						$(label).css("left", event.pageX+12);
						$(label).html(Utils.timeToDisplayTime(ui.value));
						
						//prevent adjustment of the seeking bar while sliding
						this.isSeeking = true;
						clearTimeout(this.isSeekingTimeoutHandle);
						this.isSeekingTimeoutHandle = setTimeout($.proxy(function() {
							this.isSeeking = false;
						}, this), 1000);
					}, this),
					//after sliding
					stop: $.proxy(function(event, ui) {
						//hide label
						$(label).css("display", "none");
					}, this)
				});

				//move slider every second
				setInterval($.proxy(this.updateSeeker, this), 1000);
				break;
				
			case "time":
				this.timeDisplayNode = node;
				break;
				
			case "volume":
				this.createPopupControl(node, "volume", "ui-icon-volume-on", {
					value: Math.round(this.getVolume()),
					min: 0,
					max: 100,
					//no proxy necessary, will be handled by createPopupControl
					slide: function(textNode, event, ui) {
						this.setVolume(ui.value);
						$(textNode).html(ui.value);
						$.cookie('ttt-volume', ui.value, {expires: 365, path: '/'});
					}
				});
				break;
				
			case "pitch":
				//check if browser supports playbackRate
				if (!this.isPitchSupported) {
					$(node).remove();
				} else {
					this.createPopupControl(node, "pitch", "ui-icon-grip-diagonal-se", {
						value: Math.round(this.getPitch()*100),
						min: 50,
						max: 200,
						step: 5,
						change: $.proxy(function(event, ui) {
							this.setPitch(ui.value/100);
						}, this),
						slide: function(textNode, event, ui) {
							$(textNode).html(ui.value);
							$.cookie('ttt-pitch', ui.value, {expires: 365, path: '/'});
						}
					});
				}
				
				break;
			}
		}, this));
		
		this.scaleSeeker();
	},
	
	
	/**
	 * Causes the DomNode triggerNode to open/close a popup containing a 
	 * slider control having the attributes options on click. 
	 * triggerNode also becomes a button containing an icon icon.
	 * 
	 * @param triggerNode	DomNode; The node opening the popup
	 * @param name			String; Identifier of the popup, used to
	 * 						open/close it programmatically.
	 * @param icon			String; The icon the triggerNode should get.
	 * @param options		Object; Options for the slider component,
	 * 						any of the jQuery UI slider options may be used.
	 */
	createPopupControl: function(triggerNode, name, icon, options) {
		//create and place node
		var node = document.createElement("div");
		$(node).addClass("popup box");
		$("body")[0].appendChild(node);
		
		this.popups[name] = {
			triggerNode: triggerNode,
			node: node,
			isPoppedUp: false
		};
		
		//slider
		var textNode = document.createElement("span");
		$(textNode).html(options.value);
		node.appendChild(textNode);
		//make textNode available to slide function
		if (options.slide) {
			options.slide = options.slide.bind(this, textNode);
		}
		
		node.appendChild(document.createTextNode("%"));
		var slider = document.createElement("div");
		$(slider).addClass("slider");
		node.appendChild(slider);
		
		//initialize ui components
		$(slider).slider($.extend({
			range: "min",
			animate: true,
			orientation: "vertical",
			step: 1
		}, options));
		
		$(triggerNode).button({
			text: false,
			icons: {
				primary: icon,
				secondary: "ui-icon-triangle-1-n"
			}
		});
		$(triggerNode).click(this.togglePopup.bind(this, name));
	},
	
	/**
	 * Places all popups in the correct position on the screen.
	 * This has to be called when resizing the window because
	 * button positions change as well.
	 */
	movePopups: function() {
		for (var name in this.popups) {
			//recalculate position
			$(this.popups[name].node).css("top", $(this.popups[name].triggerNode).offset().top-$(this.popups[name].node).height()-13);
			$(this.popups[name].node).css("left", $(this.popups[name].triggerNode).offset().left);
		}
	},
	
	
	
	/**
	 * Opens or closes a specified popup, depending on its current state.
	 * 
	 * @param name		the name of the popup to be opened
	 */
	togglePopup: function(name) {
		//do fading and set button icon triangles
		var secondaryIcon = "";
		if (this.popups[name].isPoppedUp) {
			$(this.popups[name].node).fadeOut();
			secondaryIcon = "ui-icon-triangle-1-n";
		} else {
			this.movePopups();
			$(this.popups[name].node).fadeIn();
			secondaryIcon = "ui-icon-triangle-1-s";
		}
		
		//change icon
		$(this.popups[name].triggerNode).button("option", "icons", {
			//primary icon stays the same
			primary: $(this.popups[name].triggerNode).button("option", "icons").primary,
			secondary: secondaryIcon
		});
		//set state
		this.popups[name].isPoppedUp = !this.popups[name].isPoppedUp;
	},
	
	
	
	/**
	 * Reads the thumbnail data and populates the thumbnail list.
	 */
	setupThumbnails: function() {
		var maxWidth = 0;
		for (var i = 0; i < this.data.thumbnails.length; i++) {
			var tn = document.createElement("div");
			$(tn).addClass("box");
			var label = (i+1)+". "+this.data.thumbnails[i].displayTime;
			var labelHtml = '<span class="thumbnailNumber">'+(i+1)+'.</span> <strong class="thumbnailTime">'+Utils.timeToDisplayTime(this.data.thumbnails[i].time)+'</strong> <br style="clear:both">';
			tn.innerHTML = '<img width="'+this.data.thumbnails[i].width+'" height="'+this.data.thumbnails[i].height+'" src="'+this.data.thumbnails[i].data+'" alt="'+label+'" /><br />'+labelHtml;
			$(this.thumbnailsSelector)[0].appendChild(tn);
			$(tn).on("click", function(i) {
				this.seekTo(this.data.thumbnails[i].time);
			}.bind(this, i));
			
			if (this.data.thumbnails[i].width > maxWidth) {
				maxWidth = this.data.thumbnails[i].width;
			}
		}
		
		//scaling
		$(this.thumbnailsSelector).width(maxWidth+30);
	},
	
	
	
	/**
	 * Jumps to the next or previous thumbnail in relation to the current time.
	 * 
	 * @param isBackward		Boolean; If true, go to previous thumbnail, else go to the next one.
	 */
	seekToAdjacentThumbnail: function(isBackward) {
		isBackward = isBackward || false;
		
		var currentTime = this.getCurrentTime();
		//find next/previous thumbnail
		for (var i = 0; i < this.data.thumbnails.length; i++) {
			if (this.data.thumbnails[i].time < currentTime &&
				this.data.thumbnails[i+1].time >= currentTime) {
				var index = i+1;
				if (isBackward) {
					//go to previous chapter or if previous chapter is -1, go to zeroth chapter
					index = (i > 0) ? i-1 : 0;
				}
				this.seekTo(this.data.thumbnails[index].time);
			}
		}
	},
	
	
	/**
	 * Calculates positions, widths and heights of all elements and
	 * sets it accordingly. This has to be called at initialization
	 * and on window resize.
	 * 
	 * @param noClear		Boolean; if noClear is true, do not clear
	 * 					    the CanvasPlayer. Used for rescaling while
	 * 						playing
	 */
	scaleDocument: function(noClear) {
		//calculate width and height for the canvas elements ("viewport")
		var viewportWidth = $(window).width()-$(this.thumbnailsSelector).outerWidth()-25;
		var viewportHeight = $(window).height()-$(this.containerSelector).outerHeight()-7;
		//resolution of the recording
		var maxDimensions = {w: this.canvasPlayer.prefs.framebufferWidth, h: this.canvasPlayer.prefs.framebufferHeight};
		//scaling factor
		var scale = Math.min(viewportWidth/maxDimensions.w, viewportHeight/maxDimensions.h);
		
		//changing size causes clear
		if (!noClear) {
			this.canvasPlayer.setDimensions(maxDimensions);
		}
		//if noClear is true, assert that the canvas is already scaled at maxDimensions.
		this.canvasPlayer.setScaling(maxDimensions, scale);
		
		//resize lock, this makes sure that the lock is scaled properly. will be executed on next lock
		this.onLockFunc = $.proxy(function() {
			$(this.lockSelector).width(viewportWidth);
			$(this.lockSelector).height(viewportHeight);
			$(this.lockSelector).css("background-color", "transparent");
		}, this);
		
		//resize controls
		$(this.containerSelector).width(scale*maxDimensions.w-5);
		$(this.containerSelector).parent().width(scale*maxDimensions.w+5);
		this.scaleSeeker();
	},
	
	
	
	/**
	 * Scales the seeker - calculates width of all controls and
	 * then sets the width of the seeking bar accordingly.
	 */
	scaleSeeker: function() {
		//calculate width of all control elements
		//6 is the padding used
		var width = 6;
		//iterate over controls
		$(this.containerSelector+" > *").each(function() {
			if (this.getAttribute("data-role") != "seeker") {
				width += $(this).outerWidth(true)+6;
			}
		});
		//now substract the calculated with from the overall container width and set it.
		$(this.seekerNode).width($(this.containerSelector).innerWidth()-width);
	},
	
	
	
	/**
	 * Loads the data specified and kicks off the presentation. This method
	 * is public and will be called by the data file.
	 * 
	 * @param data		Object; the data to be loaded.
	 */
	loadData: function(data) {
		this.msgCounter = 0;
		this.data = data;
		
		//initalization tasks
		this.setupThumbnails();
		this.canvasPlayer.startup(this.data.prefs);
		
		this.scaleDocument();
		
		//initialize messages objects
		for (var i = 0; i < this.data.messages.length; i++) {
			if (this.data.messages[i].type == "NewFileIndicator") {
				this.dataFilesLoaded[this.data.messages[i].id] = {loaded: false, messagePosition:i};
			}
			
			//get class from window object
			var clazz = window[this.data.messages[i].type] || Message;
			this.messages[i] = new clazz(this.canvasPlayer, this.data.messages[i]);
			
		}
		
		//put the start code inside a new function so we can 
		//wait until the audio tag has been loaded as well
		var initAndRun = $.proxy(function() {
			this.setupControls();
			
			if (this.options.autoPlay) {
				//setup sync parameter
				this.syncModifier = (this.data.messages[this.data.messages.length-1].time/(this.audioTag.duration*1000));
				
				this.audioTag.play();
				this.run();
			}
			this.unlock();
		}, this);
		 
		//wait for audio to load
		if (this.audioTag.readyState) {
			//audio tag is already ready. kick off the play
			initAndRun();
		} else {
			//connect to the loadeddata method 
			$(this.audioSelector).on("loadeddata", initAndRun);
		}
	},
	
	loadAdditionalData: function(data) {
		var newMessages = [];
		var targetPosition = (typeof this.dataFilesLoaded[data.id].messagePosition != "undefined") ? this.dataFilesLoaded[data.id].messagePosition : this.messages.length;
		
		for (var i = 0; i < data.messages.length; i++) {
			if (data.messages[i].type == "NewFileIndicator") {
				this.dataFilesLoaded[data.messages[i].id] = {loaded: false, messagePosition: targetPosition+i};
			}
			
			//get class from window object
			var clazz = window[data.messages[i].type] || Message;
			newMessages[i] = new clazz(this.canvasPlayer, data.messages[i]);
		}
		//insert new messages to correct position in messages array
		var firstPart = this.messages.slice(0, targetPosition);
		var lastPart = this.messages.slice(targetPosition+1);
		//merge arrays together: firstPart = firstPart + newMessages + lastPart
		$.merge(firstPart, newMessages);
		$.merge(firstPart, lastPart);
		this.messages = firstPart;
		
		//now update data object as well
		var dataFirstPart = this.data.messages.slice(0, targetPosition);
		var dataLastPart = this.data.messages.slice(targetPosition+1);
		$.merge(dataFirstPart, data.messages);
		$.merge(dataFirstPart, dataLastPart);
		this.data.messages = dataFirstPart;
		
		this.dataFilesLoaded[data.id].loaded = true;
	},
	
	waitUntilDataFileLoaded: function(id) {
		if (this.dataFilesLoaded[id].loaded) {
			this.unlock();
			this.resume();
		} else {
			this.lock();
			this.pause();
			this.waitForFileTimeout = setTimeout(this.waitUntilDataFileLoaded.bind(this, id), 500);
		}
	},
	
	
	
	/**
	 * Draws a message and then uses redoTimeout to call itself.
	 */
	run: function() {
		this.canvasPlayer.drawMessage(this.messages[this.msgCounter], this);
		this.msgCounter++;
		this.redoTimeout();
	},
	
	
	
	/**
	 * Calculates the time until the next message and then calls the
	 * run method after the calculated time.
	 * 
	 */
	redoTimeout: function() {
		clearTimeout(this.timeoutHandle);
		//check if a next message exists
		if (typeof this.data.messages[this.msgCounter] != "undefined") {
			//calculate timeout
			var timeout = Math.max(((this.data.messages[this.msgCounter].time-this.getCurrentTime())*this.syncModifier)/this.getPitch(), 0);
			this.timeoutHandle = setTimeout($.proxy(this.run, this), timeout);
		} else if (this.isPlaying) {
			//pause, presentation has ended
			this.togglePause();
		}
	},
	
	pause: function() {
		this.audioTag.pause();
		clearTimeout(this.timeoutHandle);
	},
	
	resume: function() {
		this.audioTag.play();
		this.redoTimeout();
	},
	
	
	
	/**
	 * Pauses or plays the presentation, depending on the current state. Also
	 * changes the icon of the play/pause control element. 
	 */
	togglePause: function() {
		if (this.isPlaying) {
			this.pause();
			//change icon
			$(this.playPauseNode).button("option", "icons", {primary: "ui-icon-play"});
		} else {
			this.resume();
			$(this.playPauseNode).button("option", "icons", {primary: "ui-icon-pause"});
		}
		this.isPlaying = !this.isPlaying;
	},
	
	
	
	
	
	/**
	 * Changes the current time of the presentation and draws the
	 * messages necessary for the change.
	 * 
	 * @param time			Number; Point of time to seek to, in milliseconds.
	 * @param noAutoPlay	Boolean; Wether the presentation should start automatically
	 * 						after seeking if paused before.
	 * @param forceStop		Boolean; Forces the presentation to stop after seeking.
	 * 						Useful for the stop button. 
	 */
	seekTo: function(time, noAutoPlay, forceStop) {
		noAutoPlay = noAutoPlay || false;
		forceStop = forceStop || false;
		
		this.lock();
		this.pause();
		
		setTimeout($.proxy(function() {
			
		//stop wait for file timeout if seeking to other position.
		clearTimeout(this.waitForFileTimeout);
		
		//clear canvas if rewind
		if (time < this.getCurrentTime()) {
			this.msgCounter = 0;
			this.canvasPlayer.clear();
		}
		
		//draw all messages until time
		while (typeof this.data.messages[this.msgCounter] != "undefined"
				&& this.data.messages[this.msgCounter].time <= time) {
			this.canvasPlayer.drawMessage(this.messages[this.msgCounter], this);
			this.msgCounter++;
		}
		
		this.setCurrentTime(time);
		this.updateSeeker();
		
		//resume
		this.resume();
		this.unlock();
		
		//play if it was paused
		if (!noAutoPlay && !this.isPlaying) {
			this.togglePause();
		//force stop
		} else if (forceStop && this.isPlaying) {
			this.togglePause();
		}
		
		}, this), 50);
	},
	
	
	
	/**
	 * Change the time the seeker displays.
	 */
	updateSeeker: function() {
		//do not change if the user is currently seeking, as it would conflict
		//with his action.
		if (!this.isSeeking) {
			$(this.seekerNode).slider("option", "value", this.getCurrentTime());
		}
		if (this.timeDisplayNode) {
			$(this.timeDisplayNode).html(Utils.timeToDisplayTime(this.getCurrentTime()));
		}
	},
	
	/**
	 * Getter and setter for the volume measured from 0 to 100
	 */
	getVolume: function() {
		return this.audioTag.volume*100;
	},
	
	setVolume: function(volume) {
		this.audioTag.volume = volume/100;
	},
	
	/**
	 * Getter and Setter for current time and maximum time, measured in milliseconds.
	 */
	getCurrentTime: function() {
		return this.audioTag.currentTime*1000;
	},
	
	setCurrentTime: function(time) {
		this.audioTag.currentTime = time/1000;
	},
	
	getMaximumTime: function() {
		return this.audioTag.duration*1000;
	},
	
	
	
	/**
	 * Feature-based test if the browser supports the pitch property.
	 */
	testPitchSupport: function() {
		//test if getter is there
		if (!('playbackRate' in this.audioTag)) {
	    	this.isPitchSupported = false;
	    	return false;
	    }
		//now try to set the value and read it back in
		var oldValue = this.audioTag.playbackRate;
	    this.audioTag.playbackRate = 0.5;
	    //set permanent attribute
	    this.isPitchSupported = (this.audioTag.playbackRate === 0.5);
	    this.audioTag.playbackRate = oldValue;
	    return this.isPitchSupported;
	},
	
	getPitch: function() {
		if (this.isPitchSupported) {
			return this.audioTag.playbackRate;
		} else {
			//no pitch support, return a factor of 1
			return 1.00;
		}
	},
	
	setPitch: function(pitch) {
		if (this.isPitchSupported) {
			this.audioTag.playbackRate = pitch;
			//pause and resume to correctly adapt timeouts
			if (this.data && this.isPlaying) {
				this.redoTimeout();
			}
		}
	},
	
	/**
	 * Displays a loading indicator over the presentation layer.
	 */
	lock: function() {
		if (this.onLockFunc) {
			this.onLockFunc();
			this.onLockFunc = null;
		}
		$(this.lockSelector).css("display", "block");
	},
	
	/**
	 * Hides the loading indicator created by the lock method.
	 */
	unlock: function() {
		$(this.lockSelector).css("display", "none");
	}
	
});