/**
 * HTML5 TTT-Player
 * 
 * @date 2012-01-12
 * @author Manuel Thurner
 * 
 * The Canvas Player class offers methods and attributes for
 * accessing and drawing onto the canvas element. It is used by both
 * the Message classes and the CanvasPlayerController class to
 * interact with the drawing surface.
 * 
 */

var CanvasPlayer = new Class({
	//context of the canvas element
	context: null,
	//canvas element
	canvas: null,
	//array of messages which are currently drawn on the 
	//annotation canvas
	currentAnnotations: [],
	//context of the annotation canvas element
	annotationContext: null,
	//canvas element the annotations are drawn onto
	annotationCanvas: null,
	//DOMNode of the cursor element
	cursorNode: null,
	
	//current scaling of the canvas elements
	scale: 1.00,
	//current bgColor used by HextileMessage to store colors
	//between multiple messages
	bgColor: "rgb(0,0,0)",
	//current fgColor used by HextileMessage
	fgColor: "rgb(255,255,255)",
	
	//these are the default protocol preferences, they are overridden
	//by the message file in the startup method.
	prefs: {
		//width of the recording
		framebufferWidth: 800,
		//height of the recording
		framebufferHeight: 600,
		//amount of bytes and bits used for the color of one pixel,
		//relevant for decoding hextiles
		bytesPerPixel: 2,
		bitsPerPixel: 16,
		//wether the least significant bit is first or last
		bigEndian: false,
		//color parameters which are used to shift the bytes of one pixel
		//around in order to get the red, blue and green parts respectively.
		redMax: 31,
		redShift: 0,
		blueMax: 63,
		blueShift: 10,
		greenMax: 31,
		greenShift: 5
	},
	
	
	
	/**
	 * Constructor, saves attributes and performs basic DOM operations
	 * on the canvas element.
	 * 
	 * @param canvasTag		DOMNode; Canvas element to be used for drawing
	 * 						the presentation.
	 */
	initialize: function(canvasTag) {
		this.canvas = canvasTag;
		this.context = this.canvas.getContext("2d");
		//create overlay canvas for annotations
		this.annotationCanvas = document.createElement("canvas");
		$(this.annotationCanvas).appendTo("body");
		$(this.annotationCanvas).css("position", "absolute");
		this.annotationContext = this.annotationCanvas.getContext("2d");
		
	},
	
	
	
	/**
	 * Clears the presentation canvas and the annotation canvas.
	 */
	clear: function() {
		//setting width forces a clear
		this.canvas.width = this.canvas.width;
		this.annotationCanvas.width = this.annotationCanvas.width;
	},
	
	
	
	/**
	 * Adds a message to the current annotations array.
	 * 
	 * @param msg		Message msg
	 */
	addAnnotation: function(msg) {
		this.currentAnnotations[this.currentAnnotations.length] = msg;
	},
	
	
	
	/**
	 * Clears all currently drawn annotations.
	 * 
	 * @param clearArray	boolean; wether the array where the current
	 * 						annotations are saved should be cleared as well.
	 */
	clearAnnotations: function(clearArray) {
		this.annotationCanvas.width = this.annotationCanvas.width;
		
		if (clearArray) {
			this.currentAnnotations = [];
		}
	},
	
	
	
	/**
	 * Clears all annotations which are drawn at the specified coordinates.
	 * 
	 * @param x			X coordinate
	 * @param y			Y coordinate
	 */
	clearAnnotationAt: function(x, y) {
		//First, check which annotations are at the specified position
		//and remove them from the currentAnnotation array. Then, clear all  
		//annotations and redraw those which are still in the array.
		for (var i = 0; i < this.currentAnnotations.length; i++) {
			if (this.currentAnnotations[i].contains(x, y)) {
				//it is in the boundary, delete
				this.currentAnnotations[i] = false;
			}
		}
		this.redrawAnnotations();
	},
	
	
	
	/**
	 * Redraws all annotations which are saved in the currentAnnotations array
	 */
	redrawAnnotations: function() {
		this.clearAnnotations();
		for (var i = 0; i < this.currentAnnotations.length; i++) {
			if (this.currentAnnotations[i]) {
				this.currentAnnotations[i].draw();
			}
		}
	},
	
	
	
	/**
	 * Sets the dimensions of both canvas elements to the specified width and height.
	 * setDimensions is only called once at initialization, setScaling is called everytime
	 * the window is resized.
	 * 
	 * @param dimensions	Object containing the attributes w and h, 
	 * 						specifying width and height respectively.
	 */
	setDimensions: function(dimensions) {
		//resetting width and height automatically clears canvas
		this.canvas.width = dimensions.w;
		this.canvas.height = dimensions.h;
		this.annotationCanvas.width = dimensions.w;
		this.annotationCanvas.height = dimensions.h;
		$(this.annotationCanvas).offset($(this.canvas).offset());
	},
	
	
	
	/**
	 * Sets the scaling of the canvas elements. To calculate the correct scale,
	 * the dimensions have to be given as well. setScaling is done everytime the
	 * window is resized, while setDimensions only is called once at initialization.
	 */
	setScaling: function(dimensions, scale) {
		this.scale = scale;
		var newWidth = Math.floor(this.canvas.width*scale)+"px";
		var newHeight = Math.floor(this.canvas.height*scale)+"px";
		
		//set style property, which only scales but does not set canvas dimensions.
		this.canvas.style.width = newWidth;
		this.canvas.style.height = newHeight;
		
		this.annotationCanvas.style.width = newWidth;
		this.annotationCanvas.style.height = newHeight;
		
		//adapt cursor. the cursor has to be rescaled and repositioned.
		if (this.cursorNode) {
			$(this.cursorNode).css({
				left: Math.round($(this.cursorNode).attr("data-x")*scale)+"px",
				top: Math.round($(this.cursorNode).attr("data-y")*scale)+"px",
				width: Math.round($(this.cursorNode).attr("data-width")*scale)+"px",
				height: Math.round($(this.cursorNode).attr("data-height")*scale)+"px"
			});
		}
	},
	
	
	
	/**
	 * Initializes the canvas element with the specified Protocol Preferences.
	 * 
	 * @param prefs		Protocol Preferences
	 */
	startup: function(prefs) {
		$.extend(this.prefs, prefs);
		
		this.context.fillStyle = this.bgColor;
		this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
	},
	
	
	
	/**
	 * Draws a message on the canvas element
	 * 
	 * @param message 	Message; the message to be drawn
	 */
	drawMessage: function(message) {
		message.draw();
	},
	
	
	
	/**
	 * Decodes an Array of Base64-encoded Strings into a byte array which
	 * is represented by an array of Numbers from 0 to 255 (2^8-1).
	 * 
	 * @param data 		String; Base64-encoded string
	 * @return 			Array of Numbers
	 */
	base64Decode: function(data) {
	    var base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
	    var byte1, byte2, byte3, char1, char2, char3, char4, bits;
	    var byteArray = [];
	 
	    //wrap data
	    if (typeof data == "string") {
	    	data = [data];
	    }
	    
	    var j = 0;
    	for (var k = 0; k < data.length; k++) {
    		var i = 0;
    		while (i < data[k].length) {
		        char1 = base64.indexOf(data[k].charAt(i++));
		        char2 = base64.indexOf(data[k].charAt(i++));
		        char3 = base64.indexOf(data[k].charAt(i++));
		        char4 = base64.indexOf(data[k].charAt(i++));
		 
		        bits = char1 << 18 | char2 << 12 | char3 << 6 | char4;
		        
		        byte1 = bits >> 16 & 0xff;
		        byte2 = bits >> 8 & 0xff;
		        byte3 = bits & 0xff;
		       
		        if (char3 == 64) {
		            byteArray[j++] = byte1;
		        } else if (char4 == 64) {
		            byteArray[j++] = byte1;
		            byteArray[j++] = byte2;
		        } else {
		            byteArray[j++] = byte1;
		            byteArray[j++] = byte2;
		            byteArray[j++] = byte3;
		        }
		    }
    	}
    	
	    return byteArray;
    }
});